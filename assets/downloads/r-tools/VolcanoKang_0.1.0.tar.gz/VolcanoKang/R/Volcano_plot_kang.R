# DEGAnalysisPkg/R/generate_volcano_plot.R

#' Generate Volcano Plot for DEG Analysis
#'
#' This function creates a volcano plot from DEG analysis results.
#'
#' @param data A dataframe containing log2FoldChange, pvalue, and gene columns.
#' @param log2fc_cutoff The log2 fold change threshold for significance.
#' @param pvalue_cutoff The p-value threshold for significance.
#' @param label_genes Logical. If TRUE, labels significant genes on the plot.
#' @return A ggplot2 object of the volcano plot.
#' @export
generate_volcano_plot <- function(data, log2fc_cutoff = 1, pvalue_cutoff = 0.05, label_genes = TRUE) {
  data <- data %>%
    mutate(neg_log10_p = -log10(pvalue),
           Significance = ifelse(pvalue < pvalue_cutoff & abs(log2FoldChange) > log2fc_cutoff, 
                                 ifelse(log2FoldChange > log2fc_cutoff, "Up", "Down"), 
                                 "NotSignif"))
  
  significant_genes <- data %>% filter(Significance != "NotSignif")
  
  p <- ggplot(data, aes(x = log2FoldChange, y = neg_log10_p, fill = Significance)) +
    geom_point(alpha = 0.8, size = 2, shape = 21, color = "black") +
    scale_fill_manual(values = c("Up" = "red", "Down" = "blue", "NotSignif" = "grey")) +
    theme_minimal() +
    labs(x = "log2 Fold Change", y = "-log10(p-value)") +
    geom_vline(xintercept = c(-log2fc_cutoff, log2fc_cutoff), col = "black", linetype = "dashed") +
    geom_hline(yintercept = -log10(pvalue_cutoff), col = "black", linetype = "dashed") +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold"),
      axis.title = element_text(face = "bold", size = 14),
      axis.text = element_text(face = "bold", size = 12),
      legend.title = element_text(face = "bold")
    )
  
  if (label_genes) {
    p <- p +
      geom_label_repel(data = subset(significant_genes, Significance == "Up"), 
                       aes(label = gene), 
                       box.padding = 0.5, 
                       point.padding = 0.5,
                       segment.color = 'grey50',
                       max.overlaps = Inf,
                       fontface = 'bold',
                       size = 4,
                       fill = alpha('red', 0.1)) +
      geom_label_repel(data = subset(significant_genes, Significance == "Down"), 
                       aes(label = gene), 
                       box.padding = 0.5, 
                       point.padding = 0.5,
                       segment.color = 'grey50',
                       max.overlaps = Inf,
                       fontface = 'bold',
                       size = 4,
                       fill = alpha('blue', 0.1))
  }
  
  return(p)
}
